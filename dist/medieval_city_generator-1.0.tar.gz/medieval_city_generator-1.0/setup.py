# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['medieval_city_generator']

package_data = \
{'': ['*']}

install_requires = \
['Fiona>=1.8.20,<2.0.0',
 'Shapely>=1.7.1,<2.0.0',
 'geopandas>=0.9.0,<0.10.0',
 'matplotlib>=3.4.2,<4.0.0',
 'numpy>=1.21.0,<2.0.0',
 'scipy>=1.7.0,<2.0.0']

setup_kwargs = {
    'name': 'medieval-city-generator',
    'version': '1.0',
    'description': 'Medieval City Generator in pure Python',
    'long_description': None,
    'author': 'Ewael',
    'author_email': 'turodoras@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.10',
}


setup(**setup_kwargs)
